// assets/ref/cross/index.js
// assets/ref/cross/index.js

export const CrossReferenceMap = {
  1: require("./1.json"),
  2: require("./2.json"),
  3: require("./3.json"),
  4: require("./4.json"),
  5: require("./5.json"),
  6: require("./6.json"),
  7: require("./7.json"),
  8: require("./8.json"),
  9: require("./9.json"),
  10: require("./10.json"),
  11: require("./11.json"),
  12: require("./12.json"),
  13: require("./13.json"),
  14: require("./14.json"),
  15: require("./15.json"),
  16: require("./16.json"),
  17: require("./17.json"),
  18: require("./18.json"),
  19: require("./19.json"),
  20: require("./20.json"),
  21: require("./21.json"),
  22: require("./22.json"),
  23: require("./23.json"),
  24: require("./24.json"),
  25: require("./25.json"),
  26: require("./26.json"),
  27: require("./27.json"),
  28: require("./28.json"),
  29: require("./29.json"),
  30: require("./30.json"),
  31: require("./31.json"),
  32: require("./32.json"),
  33: require("./33.json"),
  34: require("./34.json"),
  35: require("./35.json"),
  36: require("./36.json"),
  37: require("./37.json"),
  38: require("./38.json"),
  39: require("./39.json"),
  40: require("./40.json"),
  41: require("./41.json"),
  42: require("./42.json"),
  43: require("./43.json"),
  44: require("./44.json"),
  45: require("./45.json"),
  46: require("./46.json"),
  47: require("./47.json"),
  48: require("./48.json"),
  49: require("./49.json"),
  50: require("./50.json"),
  51: require("./51.json"),
  52: require("./52.json"),
  53: require("./53.json"),
  54: require("./54.json"),
  55: require("./55.json"),
  56: require("./56.json"),
  57: require("./57.json"),
  58: require("./58.json"),
  59: require("./59.json"),
  60: require("./60.json"),
  61: require("./61.json"),
  62: require("./62.json"),
  63: require("./63.json"),
  64: require("./64.json"),
  65: require("./65.json"),
  66: require("./66.json"),
};

// Define the structure of a single cross-reference entry
export interface CrossReferenceEntry {
  target: string;
  votes: number;
  book: string;
  ch: number;
  v: number;
  v_end?: number;
}

// Define the structure of a book JSON file (e.g., 1.json)
// The key is the verse string like "Gen.1.1"
export type BibleBookData = Record<string, CrossReferenceEntry[]>;

// Define the map of all 66 books
export type CrossReferenceMapType = Record<string | number, BibleBookData>;
